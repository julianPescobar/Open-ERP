﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raw Print")]
[assembly: AssemblyDescription("Command line Raw Print")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Tony Edgecombe")]
[assembly: AssemblyProduct("Raw Print")]
[assembly: AssemblyCopyright("Copyright Tony Edgecombe 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]


[assembly: AssemblyVersion("0.4.0.0")]
[assembly: AssemblyFileVersion("0.4.0.0")]
